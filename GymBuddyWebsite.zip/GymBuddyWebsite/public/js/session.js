import {workout1, workout2, workout3} from "./workoutslist.js";
import {Session} from "./sessionclass.js";

const session = new Session("Strength", "Chest", 20, 30);

if (window.location.pathname == "/session") {

  document.getElementById("btn-quit").addEventListener("click", function() {
    location.href = "/";
  });

  session.getSessionWorkout1().appendName(document.getElementById("h2-workouts"));

}
