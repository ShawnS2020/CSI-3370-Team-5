import {arrayWorkoutsList, workout1, workout2, workout3} from "./workoutslist.js";

class Session {

  #goal;
  #muscles;
  #minTime;
  #maxTime;
  #sessionWorkout1;

  constructor(goal, muscles, minTime, maxTime) {
    this.#goal = goal;
    this.#muscles = muscles;
    this.#minTime = minTime;
    this.#maxTime = maxTime;

    // const sessionWorkout1 = this.generateWorkouts(this.getMuscles());
    this.#sessionWorkout1 = this.generateWorkouts(muscles);
  }

  generateWorkouts(muscles) {
    // Instantiate regular expression objects with a string pattern corresponding to each muscle
    // These will be used to create arrays for workouts with similar muscles
    const bicepsRegExp = new RegExp(/biceps/);
    const tricepsRegExp = new RegExp(/triceps/);
    const chestRegExp = new RegExp(/chest/);

    // Switch statement to check which muscles were selected
    // Each case creates an array of workout objects with corresponding muscle data
    // Then returns a random workout object from the array
    switch (muscles.toLowerCase()) {

      case "biceps":
      const arrayBicepsWorkouts = new Array();
      for (let i = 0; i < arrayWorkoutsList.length; i ++ ) {
        if (bicepsRegExp.test(arrayWorkoutsList[i].getMuscles().toLowerCase())) {
          arrayBicepsWorkouts.push(arrayWorkoutsList[i]);
        }
      }
      const randomBicepsWorkout = arrayBicepsWorkouts[Math.floor(Math.random() * arrayBicepsWorkouts.length)];
      return randomBicepsWorkout;
      break;

      case "triceps":
      const arrayTricepsWorkouts = new Array();
      for (let i = 0; i < arrayWorkoutsList.length; i ++ ) {
        if (tricepsRegExp.test(arrayWorkoutsList[i].getMuscles().toLowerCase())) {
          arrayTricepsWorkouts.push(arrayWorkoutsList[i]);
        }
      }
      const randomTricepsWorkout = arrayTricepsWorkouts[Math.floor(Math.random() * arrayTricepsWorkouts.length)];
      return randomTricepsWorkout;
      break;

      case "chest":
      const arrayChestWorkouts = new Array();
      for (let i = 0; i < arrayWorkoutsList.length; i ++ ) {
        if (chestRegExp.test(arrayWorkoutsList[i].getMuscles().toLowerCase())) {
          arrayChestWorkouts.push(arrayWorkoutsList[i]);
        }
      }
      const randomChestWorkout = arrayChestWorkouts[Math.floor(Math.random() * arrayChestWorkouts.length)];
      return randomChestWorkout;
      break;
    }
  }

  getSessionWorkout1() {
    return this.#sessionWorkout1;
  }

  getGoal() {
    return this.#goal;
  }
}

export {Session};
